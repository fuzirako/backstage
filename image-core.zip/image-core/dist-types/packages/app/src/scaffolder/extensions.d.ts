export declare const CellsAndTrainsFieldExtension: import("@backstage/plugin-scaffolder-react").FieldExtensionComponent<any, {}>;
