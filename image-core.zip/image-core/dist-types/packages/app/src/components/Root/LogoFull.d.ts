import React from 'react';
declare const LogoFull: () => React.JSX.Element;
export default LogoFull;
