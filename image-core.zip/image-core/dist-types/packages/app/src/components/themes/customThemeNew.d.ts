export declare const customThemeNew: import("@material-ui/core").Theme;
