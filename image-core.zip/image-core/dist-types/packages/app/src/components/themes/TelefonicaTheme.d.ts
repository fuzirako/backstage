export declare const telefonicaTheme: import("@material-ui/core").Theme;
