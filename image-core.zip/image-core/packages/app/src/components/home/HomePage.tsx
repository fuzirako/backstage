import {
    HomePageCompanyLogo,
} from '@backstage/plugin-home';
import {Content, InfoCard, Page} from '@backstage/core-components';
import {HomePageSearchBar} from '@backstage/plugin-search';
import {
    SearchContextProvider,
} from '@backstage/plugin-search-react';
import {Grid, makeStyles} from '@material-ui/core';
import React, {useEffect, useState} from 'react';
import LogoFull from "../Root/LogoFull";
import {useApi} from "@backstage/core-plugin-api";
import {azureDevOpsApiRef} from "@backstage-community/plugin-azure-devops";
import "./bootstrap.min.css";

const useStyles = makeStyles(theme => ({
    searchBarInput: {
        maxWidth: '60vw',
        margin: 'auto',
        backgroundColor: theme.palette.background.paper,
        borderRadius: '50px',
        boxShadow: theme.shadows[1],
    },
    searchBarOutline: {
        borderStyle: 'none'
    },
    htmlContainer: {
        margin: 'auto',
        padding: theme.spacing(2),
        backgroundColor: theme.palette.background.paper,
        borderRadius: theme.shape.borderRadius,
        boxShadow: theme.shadows[1],
        marginTop: theme.spacing(2),
    }
}));

const useLogoStyles = makeStyles(theme => ({
    container: {
        margin: theme.spacing(5, 0),
    },
}));

export const HomePage = () => {
    const classes = useStyles();
    const {container} = useLogoStyles();

    const [readmeContent, setReadmeContent] = useState<string>('');
    const azureDevOpsApi = useApi(azureDevOpsApiRef);

    useEffect(() => {
        const fetchReadmeContent = async () => {
            try {
                const projectName = 'Arquitectura';
                const repositoryName = 'catalog-backstages';
                const response = await azureDevOpsApi.getReadme({
                    host: "", org: "", project: projectName, repo: repositoryName,
                    entityRef: ''
                });
                setReadmeContent(response.content);
            } catch (error) {
                console.error('Error al obtener el contenido del README', error);
            }
        };

        fetchReadmeContent().then();
    }, [azureDevOpsApi]);

    return (
        <SearchContextProvider>
            <Page themeId="home">
                <Content>
                    <Grid container justifyContent="center" spacing={6}>
                        <HomePageCompanyLogo
                            className={container}
                            logo={<LogoFull/>}
                        />
                        <Grid container item xs={12} justifyContent='center'>
                            <HomePageSearchBar
                                InputProps={{
                                    classes: {
                                        root: classes.searchBarInput,
                                        notchedOutline: classes.searchBarOutline
                                    }
                                }}
                                placeholder="Buscar"
                            />
                        </Grid>
                        <Grid container item xs={12}>
                            <Grid item xs={12} md={12}>
                                <InfoCard title="Catologo de API's & Templates de Telefonica Colombia - CoE de Desarrollo">
                                    <div dangerouslySetInnerHTML={{ __html: readmeContent }} />
                                </InfoCard>
                            </Grid>
                        </Grid>
                    </Grid>
                </Content>
            </Page>
        </SearchContextProvider>
    );
};
