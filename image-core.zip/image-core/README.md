# [Backstage](https://backstage.io)
 
This is your newly scaffolded Backstage App, Good Luck!

To start the app, run: 

```sh
yarn install
yarn dev
```

```sh
yarn tsc
yarn build:backend
docker image build . -f packages/backend/Dockerfile --tag backstage:2.3
docker tag backstage:2.3 raulrobinson/backstage:2.3
docker push raulrobinson/backstage:2.3
```