import { CatalogClient } from '@backstage/catalog-client';
import { TemplateAction } from '@backstage/plugin-scaffolder-backend';
import { Router } from 'express';
import type { PluginEnvironment } from '../types';
import { UrlReader, ContainerRunner } from '@backstage/backend-common';
import { DiscoveryApi } from '@backstage/plugin-permission-common';
import { Config } from '@backstage/config';
import { ScmIntegrations } from '@backstage/integration';
export declare const createActions: (options: {
    reader: UrlReader;
    integrations: ScmIntegrations;
    config: Config;
    containerRunner: ContainerRunner;
    catalogClient: CatalogClient;
    discovery: DiscoveryApi;
}) => TemplateAction<any>[];
export default function createPlugin({ logger, config, database, reader, discovery, }: PluginEnvironment): Promise<Router>;
