import React from 'react';
export declare const entityPage: React.JSX.Element;
