export declare const customTheme: import("@material-ui/core").Theme;
