import React from 'react';
import "./bootstrap.min.css";
export declare const HomePage: () => React.JSX.Element;
