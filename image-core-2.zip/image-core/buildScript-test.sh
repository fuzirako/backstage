#yarn install --frozen-lockfile
#yarn tsc
#yarn build:backend
#mkdir dist
#mkdir dist/app
#mkdir dist/backend
#mkdir dist/deploy
#mkdir -p dist/deploy/ingresstransversal
#cp -r packages/app/dist dist/app
#cp -r packages/backend/dist dist/backend
#cp packages/backend/Dockerfile dist/deploy
#cp despliegue/desarrollo/deployment.yml dist/deploy/
#cp despliegue/desarrollo/ingress-service-transversal.yml dist/deploy/ingresstransversal/ingress-service-transversal.yml
#cp yarn.lock dist
#cp package.json dist
#cp app-config.yaml dist
#cp app-config.production.yaml dist

# --- COMPILATION
yarn install --frozen-lockfile
yarn tsc
yarn build:backend
# --- CREATE DIRECTORIES CONTEXT
mkdir dist
mkdir dist/app
mkdir dist/packages
mkdir dist/packages/backend
mkdir dist/packages/app
mkdir dist/deploy
mkdir -p dist/deploy/ingresstransversal
mkdir -p dist/packages
# --- COPY COMPILED & MANIFESTS
cp -r packages/app dist/packages/app
cp -r packages/backend dist/packages/backend
cp despliegue/desarrollo/deployment.yml dist/deploy/
cp despliegue/desarrollo/ingress-service-transversal.yml dist/deploy/ingresstransversal/test-ingress-service-transversal.yml
# --- COPY DOCKERFILE
cp packages/backend/Dockerfile dist/deploy
# ---
cp yarn.lock dist
cp package.json dist
# ---
cp app-config.yaml dist
cp app-config.production.yaml dist

