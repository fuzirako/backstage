import React, {useEffect, useState} from 'react';
import {SearchContextProvider} from "@backstage/plugin-search-react";
import {Content, InfoCard, Page} from "@backstage/core-components";
import {Grid, makeStyles} from "@material-ui/core";
import LogoFull from "../Root/LogoFull";
import {HomePageCompanyLogo} from "@backstage/plugin-home";
import {useApi} from "@backstage/core-plugin-api";
import {azureDevOpsApiRef} from "@backstage-community/plugin-azure-devops";

const useLogoStyles = makeStyles(theme => ({
    container: {
        margin: theme.spacing(5, 0),
    },
}));

export const GuidelinesPage = () => {
    const {container} = useLogoStyles();
    const [readmeContent, setReadmeContent] = useState<string>('');
    const azureDevOpsApi = useApi(azureDevOpsApiRef);
    useEffect(() => {
        const fetchReadmeContent = async () => {
            try {
                const projectName = 'Arquitectura';
                const repositoryName = 'lineamientos-arquitectura';
                const response = await azureDevOpsApi.getReadme({
                    host: "", org: "", project: projectName, repo: repositoryName,
                    entityRef: ''
                });
                setReadmeContent(response.content);
            } catch (error) {
                console.error('Error al obtener el contenido del README', error);
            }
        };

        fetchReadmeContent().then();
    }, [azureDevOpsApi]);
    return (
        <SearchContextProvider>
            <Page themeId="home">
                <Content>
                    <Grid container justifyContent="center" spacing={6}>
                        <HomePageCompanyLogo
                            className={container}
                            logo={<LogoFull/>}
                        />
                    </Grid>
                    <Grid container item xs={12}>
                        <Grid item xs={12} md={12}>
                            <InfoCard title="Lineamientos de Arquitectura">
                                <div dangerouslySetInnerHTML={{ __html: readmeContent }} />
                            </InfoCard>
                        </Grid>
                    </Grid>
                </Content>
            </Page>
        </SearchContextProvider>
    );
};
