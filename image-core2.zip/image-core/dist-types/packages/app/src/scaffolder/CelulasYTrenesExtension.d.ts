import React from 'react';
import { FieldExtensionComponentProps } from '@backstage/plugin-scaffolder';
export declare const CelulasYTrenes: (props: FieldExtensionComponentProps<string[] | any>) => React.JSX.Element;
