import React from 'react';
declare const LogoIcon: () => React.JSX.Element;
export default LogoIcon;
