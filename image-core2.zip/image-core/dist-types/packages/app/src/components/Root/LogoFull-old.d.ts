import React from 'react';
declare const LogoFullOld: () => React.JSX.Element;
export default LogoFullOld;
