export declare const telefonicaTheme: import("@backstage/theme").UnifiedTheme;
