export declare const customThemeNew: import("@backstage/theme").UnifiedTheme;
