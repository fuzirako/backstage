export declare const customTheme: import("@backstage/theme").UnifiedTheme;
