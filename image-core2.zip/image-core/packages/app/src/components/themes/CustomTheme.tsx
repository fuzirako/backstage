import { createUnifiedTheme, lightTheme } from '@backstage/theme';

export const customTheme = createUnifiedTheme({
    palette: lightTheme.palette,
    fontFamily: 'Poppins, Arial',
    defaultPageTheme: 'home',
});
